package com.boss.aguila;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Chest;
import org.bukkit.boss.*;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.*;

/**
 * Águila de Hierro - Boss helicóptero de combate pesado.
 * Armas: ametralladora, cohetes, misiles guiados, bombas y bolas de fuego (Ghast).
 * Muerte: advertencia -> caída (espiral / directa / aterrizaje de emergencia) -> explosión -> drops.
 */
public class AguilaDeHierro extends JavaPlugin implements Listener, CommandExecutor {

    // ---------- AJUSTES ----------
    private static final double VIDA = 500.0;
    private static final double UMBRAL_DANO = 0.30;      // 30% de vida = motor dañado
    private static final int TICKS_ADVERTENCIA = 60;     // 3 segundos
    private static final float POTENCIA_IMPACTO = 3.0f;  // explosión final (no rompe bloques)
    private static final double RADIO_DROPS = 6.0;
    private static final int VARIANTE = -1;              // -1 aleatoria, 0 espiral, 1 directa, 2 emergencia
    private static final boolean DANO_A_BLOQUES = false;

    private enum Estado { ACTIVO, ADVERTENCIA, CAYENDO }

    private static class Part {
        BlockDisplay d; Vector3f t, s, ctr; boolean rotor, spinX; float off, speed = 1f;
    }

    private static class Misil { LargeFireball f; int edad; }

    private static class Heli {
        Ghast g;
        BossBar bar;
        List<Part> partes = new ArrayList<>();
        List<Misil> misiles = new ArrayList<>();
        BukkitTask task;
        Estado estado = Estado.ACTIVO;
        int tick, t, variante;
        float ang, rotorVel = 0.9f, roll, pitch, lastRoll = Float.NaN, lastPitch = Float.NaN;
        boolean danado, fallo, terminado;
        Location pos;
        double vy, theta, cx, cz;
    }

    private NamespacedKey bossKey;
    private final Map<UUID, Heli> helis = new HashMap<>();
    private final Set<UUID> bombas = new HashSet<>();
    private final Random rnd = new Random();

    @Override
    public void onEnable() {
        bossKey = new NamespacedKey(this, "aguila_boss");
        getCommand("aguila").setExecutor(this);
        Bukkit.getPluginManager().registerEvents(this, this);
    }

    @Override
    public void onDisable() {
        for (Heli h : new ArrayList<>(helis.values())) limpiar(h, true);
        helis.clear();
    }

    // =====================================================
    //  COMANDO
    // =====================================================
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 0) { s.sendMessage("§eUso: /aguila <spawn|kill>"); return true; }
        if (a[0].equalsIgnoreCase("spawn")) {
            if (!(s instanceof Player p)) { s.sendMessage("Solo jugadores."); return true; }
            spawn(p.getLocation().add(0, 15, 0));
            Bukkit.broadcastMessage("§c§l⚠ ¡El Águila de Hierro ha entrado en la zona! ⚠");
            Bukkit.broadcastMessage("§7Helicóptero de combate pesado. Ametralladoras, cohetes y misiles guiados.");
        } else if (a[0].equalsIgnoreCase("kill")) {
            for (Heli h : new ArrayList<>(helis.values())) limpiar(h, true);
            helis.clear();
            s.sendMessage("§aÁguilas de Hierro eliminadas.");
        }
        return true;
    }

    // =====================================================
    //  SPAWN + MODELO (camuflaje, marcas de escuadrón, armas)
    // =====================================================
    private void spawn(Location loc) {
        World w = loc.getWorld();
        Heli h = new Heli();

        h.g = w.spawn(loc, Ghast.class, g -> {
            g.setCustomName("§c§lÁguila de Hierro");
            g.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(VIDA);
            g.setHealth(VIDA);
            g.setPersistent(true);
            g.setRemoveWhenFarAway(false);
            g.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
            g.getPersistentDataContainer().set(bossKey, org.bukkit.persistence.PersistentDataType.BYTE, (byte) 1);
        });

        // ================= FUSELAJE =================
        add(h, w, loc, Material.GREEN_TERRACOTTA, -1f, -1f, -2f, 2f, 2f, 4f);
        add(h, w, loc, Material.GREEN_TERRACOTTA, -0.6f, -0.7f, 3.1f, 1.2f, 0.9f, 0.4f);   // cono de nariz
        add(h, w, loc, Material.GRAY_CONCRETE, -0.9f, -1.05f, -1.8f, 1.8f, 0.1f, 3.6f);    // blindaje del vientre
        // Camuflaje
        add(h, w, loc, Material.BLACK_CONCRETE, -1.02f, -0.5f, -1.6f, 2.04f, 0.7f, 1.3f);
        add(h, w, loc, Material.BROWN_TERRACOTTA, -1.02f, 0.1f, 0.2f, 2.04f, 0.8f, 1.1f);
        add(h, w, loc, Material.BLACK_CONCRETE, -0.9f, 0.98f, -1.6f, 1.2f, 0.04f, 1.2f);
        add(h, w, loc, Material.BROWN_TERRACOTTA, 0.3f, 0.98f, 0.2f, 0.6f, 0.04f, 1.4f);
        // Marcas de escuadrón
        sim(h, w, loc, Material.WHITE_CONCRETE, 1.0f, 0.2f, -1.2f, 0.05f, 0.4f, 0.8f);
        sim(h, w, loc, Material.RED_CONCRETE, 0.3f, 0f, -5.2f, 0.05f, 0.4f, 0.9f);
        sim(h, w, loc, Material.YELLOW_CONCRETE, 0.3f, -0.1f, -3.7f, 0.05f, 0.5f, 0.2f);
        sim(h, w, loc, Material.YELLOW_CONCRETE, 0.3f, -0.1f, -3.3f, 0.05f, 0.5f, 0.2f);

        // ================= CABINA Y SENSORES =================
        add(h, w, loc, Material.TINTED_GLASS, -0.8f, -0.5f, 2f, 1.6f, 1.2f, 1.1f);
        add(h, w, loc, Material.BLACK_CONCRETE, -0.85f, 0.7f, 2f, 1.7f, 0.1f, 1.1f);        // techo
        sim(h, w, loc, Material.BLACK_CONCRETE, -0.85f, -0.5f, 2.55f, 0.08f, 1.2f, 0.08f);  // postes
        add(h, w, loc, Material.BLACKSTONE, -0.25f, 0.8f, 2.9f, 0.5f, 0.4f, 0.5f);          // sensor
        add(h, w, loc, Material.LIGHT_BLUE_CONCRETE, -0.1f, 0.9f, 3.4f, 0.2f, 0.2f, 0.05f); // lente

        // ================= MINIGUN DE TORRETA (3 cañones) =================
        add(h, w, loc, Material.BLACK_CONCRETE, -0.3f, -1.15f, 2.6f, 0.6f, 0.3f, 0.6f);
        add(h, w, loc, Material.BLACKSTONE, -0.25f, -0.95f, 3.2f, 0.12f, 0.12f, 1.2f);
        add(h, w, loc, Material.BLACKSTONE, 0.13f, -0.95f, 3.2f, 0.12f, 0.12f, 1.2f);
        add(h, w, loc, Material.BLACKSTONE, -0.06f, -1.12f, 3.2f, 0.12f, 0.12f, 1.2f);
        add(h, w, loc, Material.GRAY_CONCRETE, -0.35f, -1.2f, 4.4f, 0.7f, 0.4f, 0.1f);      // boca

        // ================= MOTORES =================
        sim(h, w, loc, Material.GRAY_CONCRETE, -0.9f, 1.0f, -1.4f, 0.7f, 0.5f, 1.6f);       // góndolas
        sim(h, w, loc, Material.BLACK_CONCRETE, -0.9f, 1.1f, 0.2f, 0.7f, 0.35f, 0.1f);      // tomas de aire
        sim(h, w, loc, Material.BLACKSTONE, -0.8f, 1.1f, -1.5f, 0.5f, 0.3f, 0.1f);          // escapes
        add(h, w, loc, Material.BLACK_CONCRETE, -0.2f, 1f, -0.2f, 0.4f, 0.5f, 0.4f);        // mástil
        add(h, w, loc, Material.IRON_BLOCK, -0.35f, 1.35f, -0.35f, 0.7f, 0.3f, 0.7f);       // buje del rotor

        // ================= COLA =================
        add(h, w, loc, Material.GREEN_TERRACOTTA, -0.3f, -0.2f, -6f, 0.6f, 0.7f, 4f);
        add(h, w, loc, Material.BLACK_CONCRETE, -0.32f, -0.15f, -4.8f, 0.64f, 0.4f, 0.9f);  // camo cola
        add(h, w, loc, Material.BLACK_CONCRETE, -0.1f, 0.4f, -6f, 0.2f, 1.2f, 0.8f);        // aleta
        add(h, w, loc, Material.BLACK_CONCRETE, -0.1f, -0.6f, -6f, 0.2f, 0.4f, 0.6f);       // aleta inferior
        add(h, w, loc, Material.BLACK_CONCRETE, -0.9f, 0.1f, -5.9f, 1.8f, 0.1f, 0.6f);      // estabilizador
        add(h, w, loc, Material.RED_CONCRETE, -0.1f, 1.6f, -5.9f, 0.2f, 0.2f, 0.2f);        // baliza
        add(h, w, loc, Material.BLACK_CONCRETE, -0.03f, 0.5f, -3.0f, 0.06f, 0.5f, 0.06f);   // antena
        add(h, w, loc, Material.IRON_BLOCK, 0.33f, 0.85f, -5.75f, 0.12f, 0.2f, 0.1f);       // buje rotor de cola

        // ================= ALAS Y ARMAMENTO =================
        sim(h, w, loc, Material.GRAY_CONCRETE, 1f, -0.3f, -0.8f, 2f, 0.2f, 1.4f);           // alas
        sim(h, w, loc, Material.BLACKSTONE, 1.2f, -0.55f, -0.4f, 0.4f, 0.25f, 0.9f);        // vaina interior
        sim(h, w, loc, Material.BLACKSTONE, 2.4f, -0.8f, -0.5f, 0.5f, 0.5f, 1.2f);          // vaina de cohetes
        sim(h, w, loc, Material.RED_CONCRETE, 2.45f, -0.75f, 0.7f, 0.4f, 0.4f, 0.15f);      // punta de cohetes
        sim(h, w, loc, Material.WHITE_CONCRETE, 3.0f, -0.4f, -0.5f, 0.15f, 0.15f, 1.0f);    // misil de punta de ala
        sim(h, w, loc, Material.RED_CONCRETE, 3.0f, -0.4f, 0.5f, 0.15f, 0.15f, 0.15f);      // cabeza del misil
        add(h, w, loc, Material.RED_CONCRETE, 3.0f, -0.1f, -0.9f, 0.15f, 0.1f, 0.15f);      // luz de posición
        add(h, w, loc, Material.LIME_CONCRETE, -3.15f, -0.1f, -0.9f, 0.15f, 0.1f, 0.15f);   // luz de posición

        // ================= PATINES =================
        sim(h, w, loc, Material.BLACK_CONCRETE, 0.9f, -1.75f, -1.8f, 0.15f, 0.15f, 3.6f);
        sim(h, w, loc, Material.BLACK_CONCRETE, 0.9f, -1.6f, -1.2f, 0.12f, 0.6f, 0.12f);
        sim(h, w, loc, Material.BLACK_CONCRETE, 0.9f, -1.6f, 0.9f, 0.12f, 0.6f, 0.12f);

        // ================= ROTORES =================
        // Principal: 2 palas en cruz
        rotor(h, w, loc, Material.BLACK_CONCRETE, 7f, 0.1f, 0.3f, 0f, 1.5f, 0f, false, 1f, 0f);
        rotor(h, w, loc, Material.BLACK_CONCRETE, 7f, 0.1f, 0.3f, 0f, 1.5f, 0f, false, 1f, (float) (Math.PI / 2));
        // De cola: gira sobre el eje X, más rápido
        rotor(h, w, loc, Material.BLACK_CONCRETE, 0.05f, 1.4f, 0.12f, 0.4f, 0.95f, -5.65f, true, 2.2f, 0f);
        rotor(h, w, loc, Material.BLACK_CONCRETE, 0.05f, 1.4f, 0.12f, 0.4f, 0.95f, -5.65f, true, 2.2f, (float) (Math.PI / 2));

        h.bar = Bukkit.createBossBar("§c§lÁguila de Hierro", BarColor.RED, BarStyle.SEGMENTED_10);
        helis.put(h.g.getUniqueId(), h);
        h.task = Bukkit.getScheduler().runTaskTimer(this, () -> loop(h), 1L, 1L);
    }

    private Part base(World w, Location l, Material m, float x, float y, float z, float sx, float sy, float sz) {
        Part p = new Part();
        p.t = new Vector3f(x, y, z);
        p.s = new Vector3f(sx, sy, sz);
        p.d = w.spawn(l, BlockDisplay.class, d -> {
            d.setBlock(m.createBlockData());
            d.setPersistent(false);
            d.setTeleportDuration(1);
        });
        return p;
    }

    private void add(Heli h, World w, Location l, Material m, float x, float y, float z, float sx, float sy, float sz) {
        h.partes.add(base(w, l, m, x, y, z, sx, sy, sz));
    }

    /** Pieza simétrica: la añade en x y su espejo en el otro lado del fuselaje. */
    private void sim(Heli h, World w, Location l, Material m, float x, float y, float z, float sx, float sy, float sz) {
        add(h, w, l, m, x, y, z, sx, sy, sz);
        add(h, w, l, m, -x - sx, y, z, sx, sy, sz);
    }

    private void rotor(Heli h, World w, Location l, Material m, float sx, float sy, float sz,
                       float cx, float cy, float cz, boolean spinX, float speed, float off) {
        Part p = base(w, l, m, 0, 0, 0, sx, sy, sz);
        p.rotor = true;
        p.ctr = new Vector3f(cx, cy, cz);
        p.spinX = spinX;
        p.speed = speed;
        p.off = off;
        h.partes.add(p);
    }

    /** Coloca todas las piezas siguiendo al Ghast, con inclinación (roll/pitch) y giro de rotores. */
    private void actualizarPartes(Heli h) {
        Location b = h.g.getLocation().add(0, 2, 0);
        b.setPitch(0);
        boolean cambio = h.roll != h.lastRoll || h.pitch != h.lastPitch;
        Quaternionf R = new Quaternionf().rotateZ(h.roll).rotateX(h.pitch);
        for (Part p : h.partes) {
            p.d.teleport(b);
            if (!p.rotor && !cambio) continue;   // las piezas fijas solo se recalculan si cambia la inclinación
            Vector3f T;
            Quaternionf L;
            if (p.rotor) {
                float a = h.ang * p.speed + p.off;
                Quaternionf spin = p.spinX ? new Quaternionf().rotationX(a) : new Quaternionf().rotationY(a);
                Vector3f c = new Vector3f(p.s).mul(0.5f);
                spin.transform(c);
                T = new Vector3f(p.ctr).sub(c);
                R.transform(T);
                L = new Quaternionf(R).mul(spin);
            } else {
                T = new Vector3f(p.t);
                R.transform(T);
                L = new Quaternionf(R);
            }
            p.d.setTransformation(new Transformation(T, L, p.s, new Quaternionf()));
            p.d.setInterpolationDelay(0);
            p.d.setInterpolationDuration(1);
        }
        h.lastRoll = h.roll;
        h.lastPitch = h.pitch;
    }

    // =====================================================
    //  LOOP PRINCIPAL
    // =====================================================
    private void loop(Heli h) {
        if (!h.g.isValid()) { limpiar(h, false); return; }

        switch (h.estado) {
            case ACTIVO -> activo(h);
            case ADVERTENCIA -> advertencia(h);
            case CAYENDO -> caida(h);
        }
        if (h.terminado) return;

        h.ang += h.rotorVel;
        actualizarPartes(h);

        if (h.estado == Estado.ACTIVO) {
            h.bar.setProgress(Math.max(0, Math.min(1, h.g.getHealth() / VIDA)));
        } else {
            h.bar.setProgress(0);
        }
        if (h.tick % 20 == 0 || h.estado != Estado.ACTIVO && h.t % 20 == 0) {
            h.bar.removeAll();
            for (Player p : h.g.getWorld().getPlayers())
                if (p.getLocation().distanceSquared(h.g.getLocation()) < 120 * 120) h.bar.addPlayer(p);
        }
    }

    // =====================================================
    //  FASE ACTIVA: ataques
    // =====================================================
    private void activo(Heli h) {
        Ghast g = h.g;
        h.tick++;
        boolean dan = g.getHealth() < VIDA * UMBRAL_DANO;

        if (dan && !h.danado) {
            h.danado = true;
            h.bar.setTitle("§c§lÁguila de Hierro §8[§4MOTOR DAÑADO§8]");
            h.bar.setColor(BarColor.PURPLE);
            g.getWorld().playSound(g.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 4f, 0.6f);
            for (Player p : cerca(g.getLocation(), 80)) p.sendActionBar("§c¡Daño crítico! El motor del Águila echa humo...");
        }

        // Rotor y estabilidad
        if (dan) {
            h.rotorVel = 0.25f + rnd.nextFloat() * 0.6f;
            h.roll = (float) (Math.sin(h.tick * 0.35) * 0.18 + (rnd.nextFloat() - 0.5f) * 0.08);
            h.pitch = (float) (Math.sin(h.tick * 0.23) * 0.08);
            Location e = g.getLocation().add(0, 3.6, 0);
            g.getWorld().spawnParticle(Particle.SMOKE_LARGE, e, 3, 0.3, 0.2, 0.3, 0.02);
            for (int i = 0; i < 2; i++)
                g.getWorld().spawnParticle(Particle.CAMPFIRE_SIGNAL_SMOKE, e, 0, 0, 1, 0, 0.08);
            if (h.tick % 12 == 0) g.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, e, 12, 0.4, 0.3, 0.4, 0.3);
        } else {
            h.rotorVel = 0.9f;
            h.roll = 0;
            h.pitch = 0;
        }

        if (h.tick % 8 == 0) g.getWorld().playSound(g.getLocation(), Sound.ENTITY_BEE_LOOP, 3f, dan ? 0.3f : 0.5f);

        Player t = objetivo(g);

        // Misiles guiados en vuelo
        for (Iterator<Misil> it = h.misiles.iterator(); it.hasNext(); ) {
            Misil m = it.next();
            m.edad++;
            if (!m.f.isValid() || m.edad > 140) { if (m.f.isValid()) m.f.remove(); it.remove(); continue; }
            m.f.getWorld().spawnParticle(Particle.CAMPFIRE_COSY_SMOKE, m.f.getLocation(), 0, 0, 0.05, 0, 0.02);
            m.f.getWorld().spawnParticle(Particle.FLAME, m.f.getLocation(), 2, 0.05, 0.05, 0.05, 0.01);
            if (t == null) continue;
            Vector vel = m.f.getVelocity();
            if (vel.lengthSquared() < 0.0001) vel = m.f.getDirection();
            Vector want = t.getLocation().add(0, 1, 0).toVector().subtract(m.f.getLocation().toVector()).normalize();
            Vector nd = vel.normalize().multiply(0.84).add(want.multiply(0.16)).normalize();
            m.f.setDirection(nd);
            m.f.setVelocity(nd.clone().multiply(0.95));
        }

        if (t == null) return;
        g.setTarget(t);

        // Ametralladora giratoria
        boolean rafaga = dan ? (h.tick % 80 < 50 && h.tick % 2 == 0) : (h.tick % 100 < 40 && h.tick % 3 == 0);
        if (rafaga) disparar(g, t);

        // Cohetes (salva de 4)
        if (h.tick % (dan ? 110 : 140) == 70) {
            for (int i = 0; i < 4; i++) {
                Bukkit.getScheduler().runTaskLater(this, () -> {
                    if (h.estado == Estado.ACTIVO && g.isValid()) {
                        lanzar(g, t, 1.4f, 0.12);
                        g.getWorld().playSound(g.getLocation(), Sound.ENTITY_FIREWORK_ROCKET_LAUNCH, 3f, 0.8f);
                    }
                }, i * 4L);
            }
        }

        // Misil guiado
        if (h.tick % (dan ? 160 : 200) == 150) {
            LargeFireball f = lanzar(g, t, 2.6f, 0.0);
            Misil m = new Misil();
            m.f = f;
            h.misiles.add(m);
            for (Player p : cerca(g.getLocation(), 70)) p.sendActionBar("§c⚠ ¡MISIL GUIADO! ⚠");
            g.getWorld().playSound(g.getLocation(), Sound.ENTITY_WITHER_SHOOT, 3f, 1.6f);
        }

        // Bombas
        if (h.tick % 160 == 0) soltarBombas(g, t);
    }

    private Player objetivo(Ghast g) {
        Player best = null;
        double bd = 70 * 70;
        for (Player p : g.getWorld().getPlayers()) {
            if (p.getGameMode() != GameMode.SURVIVAL && p.getGameMode() != GameMode.ADVENTURE) continue;
            double d = p.getLocation().distanceSquared(g.getLocation());
            if (d < bd) { bd = d; best = p; }
        }
        return best;
    }

    private List<Player> cerca(Location l, double r) {
        List<Player> out = new ArrayList<>();
        for (Player p : l.getWorld().getPlayers())
            if (p.getLocation().distanceSquared(l) <= r * r) out.add(p);
        return out;
    }

    private void disparar(Ghast g, Player t) {
        Location o = g.getLocation().add(0, 0.5, 0);
        Vector dir = t.getEyeLocation().toVector().subtract(o.toVector()).normalize();
        Arrow a = g.getWorld().spawnArrow(o, dir, 3f, 6f);
        a.setShooter(g);
        a.setDamage(4.0);
        a.setPickupStatus(AbstractArrow.PickupStatus.DISALLOWED);
        a.setFireTicks(100);
        g.getWorld().playSound(o, Sound.ENTITY_BLAZE_SHOOT, 1.5f, 1.8f);
        g.getWorld().spawnParticle(Particle.FLAME, o, 3, 0.1, 0.1, 0.1, 0.01);
    }

    private LargeFireball lanzar(Ghast g, Player t, float yield, double spread) {
        Location o = g.getLocation().add(0, 1, 0);
        Vector dir = t.getEyeLocation().toVector().subtract(o.toVector()).normalize();
        dir.add(new Vector((rnd.nextDouble() - .5) * spread, (rnd.nextDouble() - .5) * spread,
                (rnd.nextDouble() - .5) * spread)).normalize();
        Location s = o.clone().add(dir.clone().multiply(3));
        return g.getWorld().spawn(s, LargeFireball.class, f -> {
            f.setShooter(g);
            f.setYield(yield);
            f.setIsIncendiary(false);
            f.setDirection(dir);
            f.setVelocity(dir.clone().multiply(0.9));
        });
    }

    private void soltarBombas(Ghast g, Player t) {
        for (int i = 0; i < 3; i++) {
            Location l = g.getLocation().add(rnd.nextDouble() * 4 - 2, -2, rnd.nextDouble() * 4 - 2);
            TNTPrimed tnt = g.getWorld().spawn(l, TNTPrimed.class);
            tnt.setFuseTicks(50);
            tnt.setSource(g);
            Vector v = t.getLocation().toVector().subtract(l.toVector()).setY(0).multiply(0.04);
            tnt.setVelocity(v.setY(-0.2));
            bombas.add(tnt.getUniqueId());
        }
        g.getWorld().playSound(g.getLocation(), Sound.ENTITY_TNT_PRIMED, 2f, 0.6f);
    }

    // =====================================================
    //  MUERTE: intercepta el golpe final
    // =====================================================
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Ghast g)) return;
        Heli h = helis.get(g.getUniqueId());
        if (h == null) return;
        if (h.estado != Estado.ACTIVO) { e.setCancelled(true); return; }
        if (g.getHealth() - e.getFinalDamage() <= 0) {
            e.setCancelled(true);
            iniciarAdvertencia(h);
        }
    }

    private void iniciarAdvertencia(Heli h) {
        Ghast g = h.g;
        h.estado = Estado.ADVERTENCIA;
        h.t = 0;
        h.pos = g.getLocation().clone();
        h.pos.setPitch(0);
        g.setHealth(1);
        g.setInvulnerable(true);
        g.setAI(false);
        g.setTarget(null);
        for (Misil m : h.misiles) if (m.f.isValid()) m.f.remove();
        h.misiles.clear();
        h.bar.setTitle("§4§l¡EL ÁGUILA CAE!");
        h.bar.setColor(BarColor.RED);

        Bukkit.broadcastMessage("§c§l¡El Águila de Hierro ha sido derribado!");
        Bukkit.broadcastMessage("§e§l¡ALEJAOS DEL ÁREA DE IMPACTO!");
        Bukkit.broadcastMessage("§7Los suministros caerán en breve.");
    }

    private void advertencia(Heli h) {
        Ghast g = h.g;
        World w = g.getWorld();
        h.t++;
        Location p = h.pos;

        // Giro errático y leve pérdida de altura
        p.setYaw(p.getYaw() + (rnd.nextFloat() - 0.5f) * 50f);
        p.add(0, -0.04, 0);
        g.teleport(p);
        h.roll = (float) (Math.sin(h.t * 0.6) * 0.5);
        h.pitch = (float) (Math.sin(h.t * 0.4 + 1) * 0.25);
        h.rotorVel = 0.3f + rnd.nextFloat() * 0.7f;

        Location motor = p.clone().add(0, 3.6, 0);
        w.spawnParticle(Particle.SMOKE_LARGE, motor, 6, 0.4, 0.3, 0.4, 0.03);
        w.spawnParticle(Particle.FIREWORKS_SPARK, motor, 8, 0.4, 0.3, 0.4, 0.2);

        // Pequeñas explosiones controladas en el motor
        if (h.t == 1 || h.t % 15 == 0) {
            w.spawnParticle(Particle.EXPLOSION_LARGE, motor, 2, 0.3, 0.3, 0.3, 0);
            w.spawnParticle(Particle.FLAME, motor, 40, 0.5, 0.4, 0.5, 0.15);
            w.spawnParticle(Particle.LAVA, motor, 15, 0.5, 0.4, 0.5, 0);
            w.playSound(motor, Sound.ENTITY_GENERIC_EXPLODE, 2.5f, 1.4f);
        }

        // Alarma metálica
        if (h.t % 5 == 0) {
            float pitch = (h.t / 5) % 2 == 0 ? 2.0f : 1.5f;
            w.playSound(p, Sound.BLOCK_NOTE_BLOCK_PLING, 5f, pitch);
            w.playSound(p, Sound.BLOCK_ANVIL_LAND, 1.5f, 1.8f);
        }

        avisoPantalla(h, 10);
        anillo(h, 6);

        if (h.t >= TICKS_ADVERTENCIA) {
            h.estado = Estado.CAYENDO;
            h.t = 0;
            h.variante = VARIANTE >= 0 ? VARIANTE : rnd.nextInt(3);
            h.cx = p.getX();
            h.cz = p.getZ();
            h.theta = 0;
            h.vy = 0.15;
            h.fallo = false;
            w.playSound(p, Sound.ENTITY_ENDER_DRAGON_GROWL, 4f, 0.5f);
        }
    }

    private void avisoPantalla(Heli h, int cada) {
        if (h.t % cada != 0) return;
        String col = (h.t / cada) % 2 == 0 ? "§c§l" : "§4§l";
        for (Player pl : cerca(h.g.getLocation(), 80))
            pl.sendTitle(col + "⚠ ¡ALEJAOS! ¡CAE! ⚠", "§eÁrea de impacto", 0, cada + 4, 4);
    }

    /** Anillo rojo en el suelo que marca la zona de peligro. */
    private void anillo(Heli h, int cada) {
        if (h.t % cada != 0) return;
        Location s = h.g.getLocation().add(0, 2, 0);
        RayTraceResult r = h.g.getWorld().rayTraceBlocks(s, new Vector(0, -1, 0), 200, FluidCollisionMode.NEVER, true);
        if (r == null) return;
        Vector hp = r.getHitPosition();
        Particle.DustOptions dust = new Particle.DustOptions(Color.RED, 2f);
        for (int i = 0; i < 32; i++) {
            double a = i * Math.PI * 2 / 32;
            h.g.getWorld().spawnParticle(Particle.REDSTONE, hp.getX() + Math.cos(a) * 7, hp.getY() + 0.3,
                    hp.getZ() + Math.sin(a) * 7, 1, 0, 0, 0, 0, dust);
        }
    }

    // =====================================================
    //  CAÍDA (3 variantes) + IMPACTO
    // =====================================================
    private void caida(Heli h) {
        Ghast g = h.g;
        World w = g.getWorld();
        h.t++;
        Location p = h.pos;
        double paso;      // cuánto baja este tick

        switch (h.variante) {
            case 0 -> { // ESPIRAL
                h.theta += 0.28;
                double r = Math.min(4.0, h.t * 0.15);
                paso = Math.min(1.5, 0.15 + h.t * 0.022);
                h.roll = 0.6f;
                h.pitch = 0.25f;
                h.rotorVel = 0.8f;
                p.setYaw(p.getYaw() + 28);
                p.setX(h.cx + Math.cos(h.theta) * r);
                p.setZ(h.cz + Math.sin(h.theta) * r);
            }
            case 1 -> { // DIRECTA con rotor girando
                paso = Math.min(1.8, 0.2 + h.t * 0.045);
                h.roll = 0;
                h.pitch = 0.6f;
                h.rotorVel = 0.9f;
                p.setYaw(p.getYaw() + 3);
            }
            default -> { // ATERRIZAJE DE EMERGENCIA que falla
                if (!h.fallo) {
                    double rad = Math.toRadians(p.getYaw());
                    p.add(-Math.sin(rad) * 0.35, 0, Math.cos(rad) * 0.35);
                    paso = 0.18;
                    h.roll = (float) (Math.sin(h.t * 0.3) * 0.2);
                    h.pitch = -0.1f;
                    h.rotorVel = 0.6f;
                    Location s = p.clone().add(0, 2, 0);
                    RayTraceResult r = w.rayTraceBlocks(s, new Vector(0, -1, 0), 8, FluidCollisionMode.NEVER, true);
                    if (r != null || h.t > 100) {
                        h.fallo = true;
                        h.vy = 0.2;
                        w.playSound(p, Sound.BLOCK_BEACON_DEACTIVATE, 4f, 0.5f);
                        w.spawnParticle(Particle.EXPLOSION_LARGE, p.clone().add(0, 3.6, 0), 2, 0.3, 0.3, 0.3, 0);
                        for (Player pl : cerca(p, 80)) pl.sendActionBar("§c§l¡FALLA TOTAL DE MOTOR!");
                    }
                } else {
                    h.vy = Math.min(1.8, h.vy + 0.07);
                    paso = h.vy;
                    h.pitch = Math.min(0.9f, h.pitch + 0.05f);
                    h.roll += 0.04f;
                    h.rotorVel = 0.15f;
                    p.setYaw(p.getYaw() + 12);
                }
            }
        }

        // Humo y fuego durante la caída
        Location motor = p.clone().add(0, 3.2, 0);
        w.spawnParticle(Particle.SMOKE_LARGE, motor, 5, 0.4, 0.3, 0.4, 0.03);
        w.spawnParticle(Particle.FLAME, p.clone().add(0, 2, 0), 6, 0.6, 0.4, 0.6, 0.02);
        if (h.t % 6 == 0) w.playSound(p, Sound.BLOCK_NOTE_BLOCK_PLING, 4f, h.t % 12 == 0 ? 2f : 1.5f);
        avisoPantalla(h, 20);
        anillo(h, 8);

        // ¿Toca el suelo en este tick?
        Location s = p.clone().add(0, 2, 0);
        RayTraceResult hit = w.rayTraceBlocks(s, new Vector(0, -1, 0), paso + 2.5, FluidCollisionMode.NEVER, true);
        if (hit != null) {
            Vector hp = hit.getHitPosition();
            crash(h, new Location(w, hp.getX(), hp.getY(), hp.getZ()), hit.getHitBlock());
            return;
        }
        p.add(0, -paso, 0);
        g.teleport(p);
    }

    private void crash(Heli h, Location at, Block suelo) {
        if (h.terminado) return;
        h.terminado = true;
        World w = at.getWorld();

        // Explosión de impacto: daña cerca, NO rompe bloques ni hace fuego
        w.createExplosion(at, POTENCIA_IMPACTO, false, false, h.g);
        w.spawnParticle(Particle.EXPLOSION_HUGE, at, 4, 1.5, 0.5, 1.5, 0);
        w.spawnParticle(Particle.FLAME, at.clone().add(0, 1, 0), 120, 2, 1, 2, 0.15);
        w.spawnParticle(Particle.LAVA, at.clone().add(0, 1, 0), 40, 2, 1, 2, 0);
        w.spawnParticle(Particle.SMOKE_LARGE, at.clone().add(0, 1, 0), 60, 2, 1.5, 2, 0.05);
        w.playSound(at, Sound.ENTITY_GENERIC_EXPLODE, 6f, 0.6f);
        w.playSound(at, Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 6f, 0.8f);

        limpiar(h, true);

        // Drops tras la explosión
        Bukkit.getScheduler().runTaskLater(this, () -> soltarDrops(at, suelo), 10L);

        // Restos humeantes
        new org.bukkit.scheduler.BukkitRunnable() {
            int n = 0;
            public void run() {
                if (n++ > 30) { cancel(); return; }
                w.spawnParticle(Particle.CAMPFIRE_SIGNAL_SMOKE, at.clone().add(0, 1, 0), 0, 0, 1, 0, 0.08);
                w.spawnParticle(Particle.FLAME, at.clone().add(0, 0.5, 0), 4, 1, 0.3, 1, 0.01);
            }
        }.runTaskTimer(this, 5L, 10L);
    }

    // =====================================================
    //  DROPS
    // =====================================================
    private void soltarDrops(Location at, Block suelo) {
        World w = at.getWorld();

        // Experiencia
        for (int i = 0; i < 30; i++) {
            Location l = at.clone().add(rnd.nextDouble() * 4 - 2, 1, rnd.nextDouble() * 4 - 2);
            w.spawn(l, ExperienceOrb.class, o -> o.setExperience(100));
        }

        // Caja de suministro militar (cofre en el punto de impacto)
        Block cb = suelo != null ? suelo.getRelative(BlockFace.UP) : at.getBlock();
        for (int i = 0; i < 3 && !cb.getType().isAir(); i++) cb = cb.getRelative(BlockFace.UP);
        if (cb.getType().isAir()) {
            cb.setType(Material.CHEST);
            Chest chest = (Chest) cb.getState();
            chest.setCustomName("§6§lCaja de Suministro Militar");
            chest.update();
            llenarCaja(((Chest) cb.getState()).getBlockInventory());
        }

        // Drops esparcidos en radio controlado
        List<ItemStack> sueltos = new ArrayList<>();
        sueltos.add(new ItemStack(Material.ARROW, 64));
        sueltos.add(new ItemStack(Material.ARROW, 64));
        sueltos.add(new ItemStack(Material.FIREWORK_ROCKET, 32 + rnd.nextInt(33)));
        sueltos.add(new ItemStack(Material.GUNPOWDER, 16 + rnd.nextInt(17)));
        sueltos.add(new ItemStack(Material.IRON_BLOCK, 4 + rnd.nextInt(5)));
        sueltos.add(new ItemStack(Material.REDSTONE_BLOCK, 2 + rnd.nextInt(4)));
        sueltos.add(new ItemStack(Material.GOLDEN_APPLE, 3 + rnd.nextInt(4)));
        String[] nombres = {"Casco Táctico", "Chaleco Blindado", "Pantalón Militar", "Botas de Combate"};
        Material[] piezas = {Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE,
                Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS};
        for (int i = 0; i < 4; i++) if (rnd.nextInt(100) < 60) sueltos.add(armadura(piezas[i], nombres[i]));

        for (ItemStack it : sueltos) {
            double ang = rnd.nextDouble() * Math.PI * 2;
            double d = Math.sqrt(rnd.nextDouble()) * RADIO_DROPS;
            Location dl = at.clone().add(Math.cos(ang) * d, 1.5, Math.sin(ang) * d);
            Item item = w.dropItem(dl, it);
            item.setVelocity(new Vector((rnd.nextDouble() - .5) * 0.2, 0.35, (rnd.nextDouble() - .5) * 0.2));
            item.setGlowing(true);
        }
        w.playSound(at, Sound.ENTITY_PLAYER_LEVELUP, 3f, 1f);
        w.spawnParticle(Particle.TOTEM, at.clone().add(0, 1, 0), 80, 1.5, 1, 1.5, 0.4);
    }

    private void llenarCaja(org.bukkit.inventory.Inventory inv) {
        List<ItemStack> l = new ArrayList<>();
        l.add(nucleoRotor());                                            // exclusivo, siempre
        l.add(new ItemStack(Material.NETHERITE_SCRAP, 3 + rnd.nextInt(4)));
        l.add(new ItemStack(Material.DIAMOND, 8 + rnd.nextInt(9)));
        if (rnd.nextInt(100) < 60) l.add(minigun());
        if (rnd.nextInt(100) < 50) { l.add(lanzamisiles()); l.add(new ItemStack(Material.FIREWORK_ROCKET, 16 + rnd.nextInt(17))); }
        if (rnd.nextInt(100) < 60) l.add(escudoTemporal());
        if (rnd.nextInt(100) < 25) l.add(new ItemStack(Material.NETHERITE_INGOT, 1));
        if (rnd.nextInt(100) < 40) l.add(new ItemStack(Material.TOTEM_OF_UNDYING, 1));
        if (rnd.nextInt(100) < 25) l.add(new ItemStack(Material.ENCHANTED_GOLDEN_APPLE, 1));
        for (ItemStack it : l) {
            int slot;
            do { slot = rnd.nextInt(inv.getSize()); } while (inv.getItem(slot) != null);
            inv.setItem(slot, it);
        }
    }

    // ---------- Objetos exclusivos ----------
    private ItemStack nucleoRotor() {
        ItemStack i = new ItemStack(Material.NETHER_STAR);
        ItemMeta m = i.getItemMeta();
        m.setDisplayName("§b§lNúcleo de Rotor");
        m.setLore(List.of("§7Pieza central del rotor del", "§7Águila de Hierro.", "§8Material de fabricación avanzado."));
        m.addEnchant(Enchantment.DURABILITY, 1, true);
        m.addItemFlags(ItemFlag.HIDE_ENCHANTS);
        i.setItemMeta(m);
        return i;
    }

    private ItemStack minigun() {
        ItemStack i = new ItemStack(Material.BOW);
        ItemMeta m = i.getItemMeta();
        m.setDisplayName("§c§lMinigun M134");
        m.setLore(List.of("§7Arma exclusiva del Águila de Hierro.", "§8Lluvia de plomo."));
        m.addEnchant(Enchantment.ARROW_DAMAGE, 5, true);
        m.addEnchant(Enchantment.ARROW_INFINITE, 1, true);
        m.addEnchant(Enchantment.ARROW_FIRE, 1, true);
        m.setUnbreakable(true);
        i.setItemMeta(m);
        return i;
    }

    private ItemStack lanzamisiles() {
        ItemStack i = new ItemStack(Material.CROSSBOW);
        ItemMeta m = i.getItemMeta();
        m.setDisplayName("§6§lLanzamisiles RPG");
        m.setLore(List.of("§7Arma exclusiva del Águila de Hierro.", "§8Usa cohetes de fuegos artificiales."));
        m.addEnchant(Enchantment.QUICK_CHARGE, 3, true);
        m.addEnchant(Enchantment.MULTISHOT, 1, true);
        m.addEnchant(Enchantment.DURABILITY, 3, true);
        i.setItemMeta(m);
        return i;
    }

    private ItemStack escudoTemporal() {
        ItemStack i = new ItemStack(Material.SHIELD);
        ItemMeta m = i.getItemMeta();
        m.setDisplayName("§aEscudo Táctico §7(temporal)");
        m.setLore(List.of("§7Blindaje de emergencia.", "§8Durabilidad muy limitada."));
        ((Damageable) m).setDamage(Material.SHIELD.getMaxDurability() - 40);
        i.setItemMeta(m);
        return i;
    }

    private ItemStack armadura(Material mat, String nombre) {
        ItemStack i = new ItemStack(mat);
        LeatherArmorMeta m = (LeatherArmorMeta) i.getItemMeta();
        m.setColor(Color.fromRGB(45, 60, 35));
        m.setDisplayName("§2" + nombre);
        m.setLore(List.of("§7Armadura militar del Águila de Hierro."));
        m.addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4, true);
        m.addEnchant(Enchantment.PROTECTION_EXPLOSIONS, 3, true);
        m.addEnchant(Enchantment.DURABILITY, 3, true);
        i.setItemMeta(m);
        return i;
    }

    // =====================================================
    //  EXPLOSIONES (sin romper bloques)
    // =====================================================
    private boolean esDelBoss(Entity e) {
        if (e instanceof Ghast g && helis.containsKey(g.getUniqueId())) return true;
        if (e instanceof Fireball f && f.getShooter() instanceof Ghast gh && helis.containsKey(gh.getUniqueId())) return true;
        return false;
    }

    @EventHandler
    public void onExplode(EntityExplodeEvent e) {
        boolean boss = bombas.remove(e.getEntity().getUniqueId()) || esDelBoss(e.getEntity());
        if (boss && !DANO_A_BLOQUES) e.blockList().clear();
    }

    /** Si muriera por otra vía (void, etc.), estrellarlo igualmente. */
    @EventHandler
    public void onDeath(EntityDeathEvent e) {
        Heli h = helis.get(e.getEntity().getUniqueId());
        if (h == null) return;
        e.getDrops().clear();
        e.setDroppedExp(0);
        Location l = e.getEntity().getLocation();
        crash(h, l, null);
    }

    // =====================================================
    //  LIMPIEZA
    // =====================================================
    private void limpiar(Heli h, boolean removeGhast) {
        if (h.task != null) h.task.cancel();
        for (Part p : h.partes) p.d.remove();
        h.partes.clear();
        for (Misil m : h.misiles) if (m.f.isValid()) m.f.remove();
        h.misiles.clear();
        h.bar.removeAll();
        helis.remove(h.g.getUniqueId());
        if (removeGhast) h.g.remove();
    }
}
